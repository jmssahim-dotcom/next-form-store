NEXT FORM — Upgraded Storefront UI Prototype

OPEN THE WEBSITE
1. Extract the ZIP file.
2. Open the next-form-website folder.
3. Double-click index.html to open it in Chrome, Edge, Firefox or Safari.
4. Use the Admin button in the top navigation to manage the demo catalogue.

WHAT IS INCLUDED
- Responsive desktop and mobile storefront.
- Separate Featured pieces section on the homepage.
- Product catalogue with category filters, search and sorting.
- Product details with price, compare-at price, colour, sizes, stock and description.
- Product photo upload (images are resized before saving) or image URL.
- Add to bag, cart quantity controls, and Buy Now shortcut to checkout.
- Demo checkout form and local order list in Admin > Orders.
- Admin add, edit and delete products.
- One-click “Add to home” / “On homepage” control for each product.
- Export product catalogue as JSON and demo orders as CSV.
- Product changes, cart and demo orders are stored in this browser using localStorage.

IMPORTANT LIMITATIONS BEFORE PUBLIC LAUNCH
- This is a front-end prototype, not a production commerce backend.
- Admin is not protected by real authentication. Do not publish this prototype with real customer data.
- Product data, uploaded images, cart and orders are stored only in the current browser/device. Other customers and devices will not share updates.
- Checkout records a demo order locally. It does not collect payment, send an order to the owner, or arrange delivery.
- For a live store, connect a secure database/API, admin authentication and role checks, cloud image storage, server-side stock/order validation, delivery workflow, privacy/terms pages and a payment provider available in Bangladesh.
- Replace sample images with product photos you own or have permission to use. Google Fonts and remote sample images require internet access.
